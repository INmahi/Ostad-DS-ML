
#PROBLEM 1: Write a Python program that takes a number as input and checks whether it is even or odd.

num = int(input("Enter A Number: "))

if num%2==0:
    print("Even")
else:
    print("Odd")


