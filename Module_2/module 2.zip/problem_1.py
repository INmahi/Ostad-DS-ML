def avg(num1,num2):
    return (num1+num2)/2

print(avg(3,5))
print(avg(12,54))
print(avg(123,432))