ls = ["apple", "banana", "cherry", "kiwi", "grape"]

def sort_list(list_name):
    list_name.sort()
    return list_name

print(sort_list(ls))